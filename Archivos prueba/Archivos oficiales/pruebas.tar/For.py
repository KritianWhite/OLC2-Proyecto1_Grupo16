element1 = "hola buenas"
element2 = [1,2,3,4,5,6]

for element in element1:
    print(element)

for element in element2:
    print(element)

for element in range(9):
    print(element)

for i in range(4):
    for j in range(4):
        print(i + j)
