a = 123
b = 12.3123
c = False
d = True
e = "hola buenas"
suma = a + b
resta = b - a
multiplicacion = 123 * 32
division = 54 / 4
potencia = 12 ** 3
logica = True or False and True and False 
relacionales = 123 > 32 == 43

print(a)
print(b)
print(c)
print(d)
print(e)
print(suma)
print(resta)
print(multiplicacion)
print(division)
print(potencia)
print(logica)
print(relacionales)
