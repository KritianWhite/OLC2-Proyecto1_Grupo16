if(True or False):
    print("esta es`")


if(True):
    print("este es")
else:
    print("este no es")


if(False):
    print("este no es")
else:
    print("este es")

if(True):
    print("este es")
elif(True):
    print("este no es")
else:
    print("este no es")

if(False):
    print("este no es")
elif(True):
    print("este es")
else:
    print("este no es")

if(False):
    print("este no es")
elif(False):
    print("este no es")
else:
    print("este es")
    